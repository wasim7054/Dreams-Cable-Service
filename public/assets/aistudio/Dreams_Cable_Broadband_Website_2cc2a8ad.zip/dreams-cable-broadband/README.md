# Dream's Cable and Broadband Service

A Bengali-first, responsive React + TypeScript website with a white / grass-green nature theme.

## Run locally
1. Install Node.js 18 or newer.
2. Open this folder in a terminal.
3. Run `npm install`
4. Run `npm run dev`
5. Open the local URL shown by Vite.

## Production build
Run `npm run build`. The production site will be generated in `dist/`.

## Booking
The booking form validates the Indian mobile number and opens WhatsApp with a pre-filled booking message to +91 95931 27054. No server-side booking storage is configured.

## Before publishing
- Confirm the pricing, offers, installation coverage and terms.
- Replace the illustrated family/hero artwork with a licensed image if desired.
- Add a backend if you want booking requests stored automatically.
