import { useMemo, useState } from 'react'
import {
  House, Tv, Wifi, Info, Headphones, Phone, MessageCircle, ArrowRight,
  CheckCircle2, ShieldCheck, Zap, IndianRupee, Leaf, Menu, X, CalendarDays,
  Send, Router, SatelliteDish, MonitorPlay, Signal, Sparkles
} from 'lucide-react'

const PHONE = '9593127054'
const WHATSAPP = '919593127054'

type Service = 'SD Cable TV' | 'HD Cable TV' | 'Meghbela Broadband' | 'Alliance Broadband'

const planDetails: Record<Service, { price: string; speed?: string; offer: string }> = {
  'SD Cable TV': { price: '₹1,200', offer: '১ মাসের Recharge FREE' },
  'HD Cable TV': { price: '₹1,500', offer: '১ মাসের Recharge FREE' },
  'Meghbela Broadband': { price: '₹3,499', speed: '40 Mbps', offer: '৩ মাসের Recharge FREE' },
  'Alliance Broadband': { price: '₹3,499', speed: '40 Mbps', offer: '৩ মাসের Recharge FREE' },
}

function App() {
  const [menuOpen, setMenuOpen] = useState(false)
  const [service, setService] = useState<Service>('SD Cable TV')
  const [name, setName] = useState('')
  const [mobile, setMobile] = useState('')
  const [address, setAddress] = useState('')
  const [date, setDate] = useState('')
  const [message, setMessage] = useState('')
  const [submitted, setSubmitted] = useState(false)

  const selectedPlan = useMemo(() => planDetails[service], [service])

  const bookingMessage = () => {
    const text = [
      'নমস্কার, আমি Dream’s Cable and Broadband Service-এ নতুন কানেকশন নিতে চাই।',
      `নাম: ${name}`,
      `মোবাইল: ${mobile}`,
      `ঠিকানা: ${address}`,
      `কানেকশন: ${service}`,
      `প্রাথমিক কানেকশন চার্জ: ${selectedPlan.price}`,
      `অফার: ${selectedPlan.offer}`,
      `পছন্দের তারিখ: ${date || 'জানানো হয়নি'}`,
      `অতিরিক্ত বার্তা: ${message || 'নেই'}`,
    ].join('\n')
    return `https://wa.me/${WHATSAPP}?text=${encodeURIComponent(text)}`
  }

  const submitBooking = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault()
    if (!/^[6-9]\d{9}$/.test(mobile.replace(/\D/g, ''))) {
      alert('সঠিক ১০ সংখ্যার ভারতীয় মোবাইল নম্বর দিন।')
      return
    }
    setSubmitted(true)
    window.open(bookingMessage(), '_blank', 'noopener,noreferrer')
  }

  const closeMenu = () => setMenuOpen(false)

  return (
    <div className="site-shell">
      <div className="leaf leaf-one" /><div className="leaf leaf-two" /><div className="leaf leaf-three" />
      <header className="header">
        <div className="topbar wrap">
          <a className="brand" href="#home" onClick={closeMenu}>
            <span className="brand-mark"><House size={38}/><Wifi className="brand-wifi" size={24}/></span>
            <span><strong>Dream’s</strong><b>Cable and Broadband Service</b><small>Your Trusted Cable TV & Broadband Partner</small></span>
          </a>
          <div className="operator"><span>অপারেটর :</span><strong>WASIM AKRAM MONDAL</strong></div>
          <a className="head-contact" href={`tel:+91${PHONE}`}><Phone size={19}/><span><b>{PHONE}</b><small>(Call Us)</small></span></a>
          <a className="head-whatsapp" href={`https://wa.me/${WHATSAPP}`} target="_blank" rel="noreferrer"><MessageCircle size={20}/><span>WhatsApp<br/>Chat</span></a>
          <a className="pill-button header-cta" href="#booking">নতুন কানেকশন বুক করুন <ArrowRight size={16}/></a>
          <button className="menu-toggle" onClick={() => setMenuOpen(!menuOpen)} aria-label="মেনু খুলুন">{menuOpen ? <X/> : <Menu/>}</button>
        </div>
        <nav className={`nav ${menuOpen ? 'nav-open' : ''}`}>
          <div className="wrap nav-inner">
            <a href="#home" onClick={closeMenu}><House size={17}/> হোম</a>
            <a href="#cable" onClick={closeMenu}><Tv size={17}/> কেবল টিভি</a>
            <a href="#broadband" onClick={closeMenu}><Wifi size={18}/> ব্রডব্যান্ড</a>
            <a href="#about" onClick={closeMenu}><Info size={17}/> আমাদের সম্পর্কে</a>
            <a href="#contact" onClick={closeMenu}><Headphones size={17}/> যোগাযোগ</a>
          </div>
        </nav>
      </header>

      <main>
        <section className="hero wrap" id="home">
          <div className="hero-copy">
            <span className="eyebrow"><Leaf size={15}/> আপনার এলাকার বিশ্বস্ত পরিষেবা</span>
            <h1>আপনার বিশ্ব,<br/><em>আরও ভালোভাবে</em><br/>সংযুক্ত হোক!</h1>
            <p><b>Dream's Cable and Broadband Service</b>-এর সাথে উপভোগ করুন Crystal Clear Cable TV এবং High-Speed Internet!</p>
            <div className="hero-actions">
              <a className="pill-button" href="#cable"><Tv size={18}/> কেবল সংযোগ নিন <ArrowRight size={17}/></a>
              <a className="pill-button outline" href="#broadband"><Wifi size={18}/> ব্রডব্যান্ড জানুন <ArrowRight size={17}/></a>
            </div>
            <div className="hero-note"><ShieldCheck size={17}/> নির্ভরযোগ্য কানেকশন • সহজ বুকিং • বন্ধুত্বপূর্ণ সাপোর্ট</div>
          </div>
          <div className="hero-art">
            <div className="sun-glow"/><div className="hill hill-back"/><div className="hill hill-front"/>
            <div className="family-photo">
              <img src="https://images.unsplash.com/photo- family" alt="" onError={(e) => { e.currentTarget.style.display='none' }}/>
              <div className="family-emoji" aria-label="পরিবারের বিনোদন"><span>👨‍👩‍👧‍👦</span><small>একসাথে বিনোদন, একসাথে সংযোগ</small></div>
            </div>
            <div className="tv-card"><MonitorPlay size={30}/><b>Live TV</b><span>Sports • Movies • More</span><div className="tv-screen">▶　HD ENTERTAINMENT</div></div>
            <div className="router-card"><Router size={38}/><span>High-speed<br/>WiFi</span><i/><i/><i/></div>
            <div className="wifi-orbit"><Wifi size={54}/></div>
            <div className="hero-leaf l-a">✦</div><div className="hero-leaf l-b">❧</div>
          </div>
        </section>

        <section className="plans-wrap wrap" id="cable">
          <div className="section-title"><span className="title-icon"><Tv/></span><h2>কেবল টিভি সংযোগের প্ল্যান</h2><span className="title-line"/></div>
          <div className="plan-grid cable-grid">
            <article className="plan-card">
              <div className="plan-ribbon">SD কেবল সংযোগ</div>
              <div className="plan-main"><div><div className="price">₹1,200</div><span className="price-caption">প্রাথমিক কানেকশন চার্জ</span></div><div className="device-icon"><SatelliteDish size={48}/><Tv size={33}/></div></div>
              <ul><li><CheckCircle2/> SD Set Top Box সংযোগ</li><li><CheckCircle2/> ১ মাসের Recharge FREE</li><li><CheckCircle2/> সাশ্রয়ী কেবল টিভি বিনোদন</li><li><CheckCircle2/> উপলব্ধ SD Channel দেখুন</li></ul>
              <a className="card-button" href="#booking" onClick={() => setService('SD Cable TV')}>SD কানেকশন নিন <ArrowRight size={17}/></a>
            </article>
            <article className="plan-card featured">
              <span className="hot-label">HD EXPERIENCE</span>
              <div className="plan-ribbon">HD কেবল সংযোগ</div>
              <div className="plan-main"><div><div className="price">₹1,500</div><span className="price-caption">প্রাথমিক কানেকশন চার্জ</span></div><div className="device-icon hd"><Tv size={48}/><b>HD</b></div></div>
              <ul><li><CheckCircle2/> HD Set Top Box Included</li><li><CheckCircle2/> ১ মাসের Recharge FREE</li><li><CheckCircle2/> Crystal Clear HD Picture</li><li><CheckCircle2/> HD Channel উপভোগ করুন</li></ul>
              <a className="card-button" href="#booking" onClick={() => setService('HD Cable TV')}>HD কানেকশন নিন <ArrowRight size={17}/></a>
            </article>
          </div>
        </section>

        <section className="plans-wrap broadband-section wrap" id="broadband">
          <div className="section-title"><span className="title-icon"><Wifi/></span><h2>ব্রডব্যান্ড ইন্টারনেট প্ল্যান</h2><span className="title-line"/></div>
          <div className="plan-grid">
            <article className="plan-card internet-card">
              <div className="plan-ribbon">Meghbela Broadband</div>
              <div className="internet-speed">40 <small>Mbps</small></div>
              <div className="price">₹3,499</div><span className="price-caption">প্রাথমিক কানেকশন চার্জ</span>
              <ul><li><CheckCircle2/> 40 Mbps Internet Speed</li><li><CheckCircle2/> ৩ মাসের Recharge FREE</li><li><CheckCircle2/> নির্ভরযোগ্য সংযোগ</li><li><CheckCircle2/> প্রতিদিনের কাজে উপযোগী</li></ul>
              <div className="provider-wordmark meghbela">MEGHBELA <small>BROADBAND</small></div>
              <a className="card-button" href="#booking" onClick={() => setService('Meghbela Broadband')}>Meghbela নিন <ArrowRight size={17}/></a>
            </article>
            <article className="plan-card internet-card">
              <div className="plan-ribbon">Alliance Broadband</div>
              <div className="internet-speed">40 <small>Mbps</small></div>
              <div className="price">₹3,499</div><span className="price-caption">প্রাথমিক কানেকশন চার্জ</span>
              <ul><li><CheckCircle2/> 40 Mbps Internet Speed</li><li><CheckCircle2/> ৩ মাসের Recharge FREE</li><li><CheckCircle2/> নির্ভরযোগ্য সংযোগ</li><li><CheckCircle2/> প্রতিদিনের কাজে উপযোগী</li></ul>
              <div className="provider-wordmark alliance">△ Alliance <small>Broadband</small></div>
              <a className="card-button" href="#booking" onClick={() => setService('Alliance Broadband')}>Alliance নিন <ArrowRight size={17}/></a>
            </article>
          </div>
          <p className="price-note">* উপরে দেওয়া মূল্য প্রাথমিক কানেকশন চার্জ। অফার ও পরিষেবার বিস্তারিত জানতে ফোনে যোগাযোগ করুন।</p>
        </section>

        <section className="why wrap">
          <div className="floating-heading"><span>কেন আমাদের বেছে নেবেন?</span></div>
          <div className="why-grid">
            <div className="why-item"><ShieldCheck/><b>বিশ্বস্ত পরিষেবা</b><small>(Reliable Service)</small></div>
            <div className="why-item"><Zap/><b>দ্রুতগতির ইন্টারনেট</b><small>(High-Speed Internet)</small></div>
            <div className="why-item"><IndianRupee/><b>সাশ্রয়ী অফার</b><small>(Affordable Price)</small></div>
            <div className="why-item"><Headphones/><b>বন্ধুত্বপূর্ণ সাপোর্ট</b><small>(Friendly Support)</small></div>
          </div>
        </section>

        <section className="lower-grid wrap">
          <div className="partners">
            <div className="small-section-title">আমাদের পার্টনার নেটওয়ার্ক</div>
            <div className="partner-list">
              <div className="partner-logo"><b>MEGHBELA</b><small>CABLE</small></div>
              <div className="partner-logo"><b>MEGHBELA</b><small>BROADBAND</small></div>
              <div className="partner-logo alliance-logo"><b>△ Alliance</b><small>Broadband</small></div>
            </div>
          </div>
          <div className="about" id="about">
            <div className="small-section-title">আমাদের সম্পর্কে</div>
            <h3>আপনার ঘরেই নিয়ে আসছি মানসম্মত Cable TV ও Broadband Internet!</h3>
            <p>Dream's Cable and Broadband Service আপনাদের ঘরে নিয়ে আসছে মানসম্মত Cable TV ও Broadband Internet পরিষেবা। আমরা Meghbela এবং Alliance Broadband-এর মাধ্যমে সংযোগ পরিষেবা প্রদান করি। আমাদের লক্ষ্য হলো গ্রাহকদের সহজ, সাশ্রয়ী এবং ভালো পরিষেবা দেওয়া।</p>
            <strong className="operator-tag"><Leaf size={16}/> অপারেটর: WASIM AKRAM MONDAL</strong>
          </div>
        </section>

        <section className="booking-wrap wrap" id="booking">
          <div className="booking-form-panel">
            <div className="small-section-title"><CalendarDays size={19}/> নতুন কানেকশন বুকিং করুন</div>
            {submitted && <div className="success-message"><CheckCircle2/> আপনার WhatsApp বুকিং মেসেজ প্রস্তুত হয়েছে। পাঠিয়ে বুকিং নিশ্চিত করুন।</div>}
            <form onSubmit={submitBooking}>
              <div className="form-grid">
                <label>আপনার নাম *<input required value={name} onChange={e=>setName(e.target.value)} placeholder="আপনার পুরো নাম"/></label>
                <label>মোবাইল নম্বর *<input required inputMode="numeric" maxLength={10} value={mobile} onChange={e=>setMobile(e.target.value.replace(/\D/g,''))} placeholder="১০ সংখ্যার নম্বর"/></label>
                <label className="full">ঠিকানা লিখুন *<input required value={address} onChange={e=>setAddress(e.target.value)} placeholder="বাড়ি / রাস্তা / এলাকা"/></label>
                <label>Service নির্বাচন করুন *<select value={service} onChange={e=>{setService(e.target.value as Service);setSubmitted(false)}}><option>SD Cable TV</option><option>HD Cable TV</option><option>Meghbela Broadband</option><option>Alliance Broadband</option></select></label>
                <label>Selected Plan<div className="selected-plan">{service} — {selectedPlan.price} {selectedPlan.speed ? `(${selectedPlan.speed})` : ''}</div></label>
                <label>পছন্দের তারিখ<input type="date" value={date} onChange={e=>setDate(e.target.value)}/></label>
                <label>অতিরিক্ত বার্তা<textarea value={message} onChange={e=>setMessage(e.target.value)} placeholder="কিছু জানাতে চাইলে লিখুন"/></label>
              </div>
              <button className="card-button submit-button" type="submit"><Send size={17}/> জমা দিন / Submit</button>
            </form>
          </div>
          <aside className="whatsapp-panel">
            <MessageCircle size={45}/>
            <h3>অথবা WhatsApp-এ মেসেজ করুন</h3>
            <p>নতুন কানেকশন বা যেকোনো তথ্যের জন্য সরাসরি আমাদের WhatsApp করুন।</p>
            <a className="wa-button" href={`https://wa.me/${WHATSAPP}?text=${encodeURIComponent('নমস্কার, Dream’s Cable and Broadband Service-এর কানেকশন সম্পর্কে জানতে চাই।')}`} target="_blank" rel="noreferrer">Chat Now <ArrowRight size={16}/></a>
            <div className="wa-number">{PHONE}</div>
          </aside>
        </section>
      </main>

      <footer className="footer" id="contact">
        <div className="footer-grass"/>
        <div className="wrap footer-grid">
          <div className="footer-brand"><div className="footer-logo"><House/><Wifi/></div><strong>Dream’s</strong><b>Cable and Broadband Service</b><small>Your Trusted Cable TV & Broadband Partner.</small></div>
          <div><h4>যোগাযোগ করুন</h4><a href={`tel:+91${PHONE}`}><Phone size={17}/> {PHONE}</a><a href={`https://wa.me/${WHATSAPP}`} target="_blank" rel="noreferrer"><MessageCircle size={17}/> WhatsApp-এ মেসেজ করুন</a><p>অপারেটর: WASIM AKRAM MONDAL</p></div>
          <div><h4>কুইক লিংকস</h4><a href="#home">⌂　হোম</a><a href="#cable">▣　কেবল টিভি</a><a href="#broadband">◉　ব্রডব্যান্ড</a><a href="#about">ⓘ　আমাদের সম্পর্কে</a></div>
          <div className="copyright">© 2026 Dream's Cable and Broadband Service.<br/>All Rights Reserved.</div>
        </div>
      </footer>
      <a className="floating-wa" href={`https://wa.me/${WHATSAPP}`} target="_blank" rel="noreferrer" aria-label="WhatsApp-এ যোগাযোগ করুন"><MessageCircle/></a>
    </div>
  )
}

export default App
